import HomeComponent from "./components/Home";
import Details from "./components/Details";
import Slide from "./components/Slide";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import "./App.css";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Switch>
          <Route path="/" exact render={() => <><Slide/><HomeComponent/></>} />
           <Route path="/details" exact render={() => <><Details/></>} />
          </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
