// To display details of the selected widget from the Home Page
import React from "react";
import { useLocation } from "react-router-dom";

function Details() {
  const location = useLocation();
  const dataDetail = location.state.items;
  console.log("dataDetail", dataDetail);
// Displaying Details from the selected data from the API 
  return (
    <div>
      <div className="details">
        <img id="img-details" src={dataDetail.image.original} alt="" />
        <h2 id="title">{dataDetail.name}</h2>
        <br />
        <br />
        <p className="summary content-css">
          {dataDetail.summary.replace(/<\/?.+?>/gi, "")}
        </p>{" "}
        <br></br>
        <p id="para">
          Genres :{" "}
          {dataDetail.genres !== null ? dataDetail.genres : "Not Found"}
        </p>
        <p id="para">
          Language :{" "}
          {dataDetail.language !== null ? dataDetail.language : "Not Found"}
        </p>
        <p id="para">
          Rating :{" "}
          {dataDetail.rating.average !== null
            ? dataDetail.rating.average
            : "Not Found"}
        </p>
        <p id="para">
          Time :{" "}
          {dataDetail.schedule.time !== null
            ? dataDetail.schedule.time
            : "Not Found"}
        </p>
        <p id="para">
          Scheduled Day :{" "}
          {dataDetail.schedule.days !== null
            ? dataDetail.schedule.days
            : "Not Found"}
        </p>
        <p id="para">
          Premiered :{" "}
          {dataDetail.premiered !== null ? dataDetail.premiered : "Not Found"}
        </p>
        <p id="para">
          Ended : {dataDetail.ended !== null ? dataDetail.ended : "Not Found"}{" "}
        </p>
      </div>
    </div>
  );
}

export default Details;
