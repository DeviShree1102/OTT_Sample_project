// Home component to fetch and display widgets Data from APi 
import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Link } from "react-router-dom";
import { ArrowRight } from 'react-bootstrap-icons';

function HomeComponent() {
  const [prdtData, setPrdtData] = useState([]);

  //   GET API to fetch the data and display using react hook Usetate
  useEffect(() => {
    if (!prdtData.length) {
      fetch("https://api.tvmaze.com/shows")
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          if (prdtData.length !== data.length) {
            setPrdtData(data);
          }

          console.log("data", data);
        });
    }
  });
// Const to call React Slider 
  const settings = {
    arrows: true,
    infinite: false,
    slidesToShow: 5,
    slidesToScroll: 5,
    speed: 500,
    className: "slides",
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 4,
          initialSlide: 4,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
    ],
  };

  return (
    <div>
      <div className="title">Top Shows &gt;</div>
      {/* React Slider to show the widgets to slide with arrow left and right onClick */}
      <Slider {...settings}>
        {prdtData.map((post) => {
          return (
            <div className="row__posters" key={post.id}>
                {/*Click on each widget to navigate Link to Details component*/}
              <Link to={{ pathname: "/details", state: { items: post } }}>
                  {/* To display image in landing screen from API Data */}
                <img
                  className="row__poster"
                  width="100%"
                  src={post.image.medium}
                />
              </Link>
            </div>
          );
        })}
      </Slider>
    </div>
  );
}

export default HomeComponent;
